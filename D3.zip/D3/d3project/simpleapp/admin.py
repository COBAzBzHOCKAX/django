from django.contrib import admin

from .models import Category, Product, Material, ProductMaterial


class ProductAdmin(admin.ModelAdmin):
    list_display = ('name', 'quantity', 'product_category', 'price')

    def product_category(self, product):
        return ", ".join(cat.name for cat in product.category.all())

admin.site.register(Category)
admin.site.register(Product, ProductAdmin)
admin.site.register(Material)
admin.site.register(ProductMaterial)

